***************************************************
->This prestashop module can be installed and it is developed for prestashop v 1.5.3
->This module has test platform data bind with it.
->SSLCOMMERZ authority will provide the live credentials and please update your module with live credentilas one you go live.


***************************************************