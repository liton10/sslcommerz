<?php
include(dirname(__FILE__).'/../../config/config.inc.php');
include(dirname(__FILE__).'/../../header.php');
include(dirname(__FILE__).'/sslcommerz.php');

	/*
	*  Sample Cancel page. You can design and customize with required information here.
	*/
	echo "Sorry you have cancelled the payment! Please try again.";

include(dirname(__FILE__).'/../../footer.php');
?>