<?php
include(dirname(__FILE__).'/../../config/config.inc.php');
include(dirname(__FILE__).'/../../header.php');
include(dirname(__FILE__).'/sslcommerz.php');

	/*
	*  Sample fail page. You can design and customize with required information here.
	*/

	echo "Sorry your payment is failed. Please communicate to your card issuer Bank for details.";

include(dirname(__FILE__).'/../../footer.php');
?>