<?php

include(dirname(__FILE__).'/../../config/config.inc.php');
include(dirname(__FILE__).'/../../header.php');
include(dirname(__FILE__).'/sslcommerz.php');

	/*
	*  Assigns order data to smarty variables.
	*/

$smarty->assign(array(
	'amount' => floatval($cart->getOrderTotal(true, 4)),
	'total' => floatval($cart->getOrderTotal(true, 3)),
	'cart_id' => intval($cart->id)
));

	/*
	*  Checks login status and redirects if failed.
	*/

if (!$cookie->isLogged())
    Tools::redirect('authentication.php?back=order.php');
	
$sslcommerz = new sslcommerz();
echo $sslcommerz->execPayment($cart);

include_once(dirname(__FILE__).'/../../footer.php');

?>