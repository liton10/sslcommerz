<?php 
include(dirname(__FILE__).'/../../config/config.inc.php');
include(dirname(__FILE__).'/../../header.php');
include(dirname(__FILE__).'/sslcommerz.php');
			

	/* 
	*Gather submitted payment validation id and cross checks the payment 
	*If the validation fails the customer is redirected to fail page
	*/
	
	if(isset($_POST['val_id'])){
	
		$val_id = $_POST['val_id'];
		
		/* 
		* Call payment validation API in test box. For live box integration use the following URL
		* https://www.sslcommerz.com.bd/validator/validationserver.php?wsdl
		*/
		
		try{
			$c = new soapclient('https://www.sslcommerz.com.bd/testbox/validator/validationserver.php?wsdl');
			}
		catch (Exception $e) {
			echo 'Caught exception: ',  $e->getMessage(), "\n";
			}
			$res = $c-> checkValidation($val_id);
		
		
		if (strcmp ($res, "VALID") == 0) {
			
		/* 
		* Order confirmation action to be taken after a valid response.
		*/
		
			$currency = new Currency(intval(isset($_POST['currency_payement']) ? $_POST['currency_payement'] : $cookie->id_currency));
			$total = floatval(number_format($cart->getOrderTotal(true, 3), 2, '.', ''));
			
			$sslcommerz = new sslcommerz();
			$sslcommerz->validateOrder($cart->id,  _PS_OS_PREPARATION_, $total, $sslcommerz->displayName, NULL, NULL, $currency->id);
			$order = new Order($sslcommerz->currentOrder);
			$sslcommerz->writePaymentcarddetails($order->id, 'paid');
			Tools::redirectLink(__PS_BASE_URI__.'order-confirmation.php?id_cart='.$cart->id.'&id_module='.$sslcommerz->id.'&id_order='.$sslcommerz->currentOrder.'&key='.$order->secure_key);
		
		
		}
		
		else
		{
			Tools::redirect('modules/sslcommerz/failed.php');
		}
	
	
	}
	
	else
	{
		Tools::redirect('modules/sslcommerz/failed.php');
	}


?>